Theme design/layout settings (configured in: System > Configuration) are stored in the CSS files which can be found inside folder "_config".

IMPORTANT:
If you're creating a sub-theme to customize the theme, do not copy folder "_config" (or files stored inside) to your sub-theme!