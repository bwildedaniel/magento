<?php

$installer = $this;

//Remove attributes
$installer->removeAttribute('catalog_category', 'umm_cat_block_proportions');
$installer->removeAttribute('catalog_category', 'umm_cat_block_top');
$installer->removeAttribute('catalog_category', 'umm_cat_block_bottom');
$installer->removeAttribute('catalog_category', 'umm_cat_block_right');
